from flask import Flask, render_template, redirect, request, session
from flask_session import Session
import requests,os
from secret_config143 import config as CONFIG

os.chdir('/var/www/html/mysecretapp')
app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config['SESSION_TYPE'] = 'filesystem'
import json
Session(app)

base_endpoind = "/myapp"
@app.route("/")
def index():
    if not session.get("username"):
        return redirect(base_endpoind+"/login")
    return render_template('index.html')

@app.route("/requestsasaservice")
def requestsasaservice():
    if not session.get("username"):
        return redirect(base_endpoind+"/login")
    return render_template('requestsasaservice.html')  

@app.route("/get",methods=["POST", "GET"])
def get():
    try:
        if not session.get("username"):
            return redirect(base_endpoind+"/login")
        response = None
        status_code=None
        if request.method == "POST":
            url = request.form.get("url")
            if "127.0.0.1" in url or "0.0.0.0" in url or "localhost" in url:
                return "Hacker Gonna Hack"
            cookies=request.form.get("cookies")
            if cookies:
                cookies = json.loads(request.form.get("cookies"))
            else:
                cookies = None
            headers=request.form.get("headers")
            if headers:
                headers = json.loads(request.form.get("headers"))
            else:
                headers = None
            r =requests.get(url,cookies=cookies,headers=headers)
            status_code = r.status_code
            response = r.text
        return render_template('get.html',response=response,status_code=status_code ) 
    except:
        return "error bang"

@app.route("/post",methods=["POST", "GET"])
def post():
    try:
        if not session.get("username"):
            return redirect(base_endpoind+"/login")
        response = None
        status_code=None
        if request.method == "POST":
            url = request.form.get("url")
            cookies=request.form.get("cookies")
            if "127.0.0.1" in url or "0.0.0.0" in url or "localhost" in url:
                return "Hacker Gonna Hack"
            if cookies:
                cookies = json.loads(request.form.get("cookies"))
            else:
                cookies = None
            headers=request.form.get("headers")
            if headers:
                headers = json.loads(request.form.get("headers"))
            else:
                headers = None
            type=request.form.get("type")
            if type == "json":
                if request.form.get("data"):
                    jsonData = json.loads(request.form.get("data"))
                else:
                    jsonData=None
                r =requests.post(url,cookies=cookies,headers=headers,json=jsonData)
            elif type == "form-data":
                if request.form.get("data"):
                    Data = json.loads(request.form.get("data"))
                else:
                    Data = None
                r =requests.post(url,cookies=cookies,headers=headers,data=Data)                
            elif type == "raw_data":
                Data= request.form.get("data")
                r =requests.post(url,cookies=cookies,headers=headers,data=Data)     
            else:
                Data= request.form.get("data")
                r =requests.post(url,cookies=cookies,headers=headers,data=Data) 
            status_code = r.status_code
            response = r.text
        return render_template('post.html',response=response,status_code=status_code ) 
    except Exception as e :
        return "error bang"

@app.route("/secretservice")
def secretservice():
    if not session.get("username"):
        return redirect(base_endpoind+"/login")
    return redirect("http://127.0.0.1:6969/")

@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == CONFIG.USERNAME and password == CONFIG.PASSWORD:
            session["username"] =username
        return redirect(base_endpoind+"/")
    return render_template("login.html")
  
  
@app.route("/logout")
def logout():
    session["username"] = None
    return redirect(base_endpoind+"/")
  
  
if __name__ == "__main__":
    app.run(debug=True)
