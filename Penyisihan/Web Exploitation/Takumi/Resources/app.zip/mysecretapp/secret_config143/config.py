import os
from dotenv import load_dotenv
os.chdir("/var/www/html/mysecretapp/secret_config143")
load_dotenv('.env') 

USERNAME = os.getenv("SECRET_USER")
PASSWORD = os.getenv("SECRET_PASS")