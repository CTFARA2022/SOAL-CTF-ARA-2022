from crypt import methods
from requests import request
from flask import Flask,render_template
from flask import request

from xml.dom.pulldom import parse,parseString
from xml.sax import make_parser
from xml.sax.handler import feature_external_ges
from xml.dom import pulldom

app = Flask(__name__)

@app.route('/',methods=["GET"])
def hello():
    return render_template('index.html')

@app.route('/contact_me',methods=["POST"])
def contact_me():
    try:
        parser = make_parser()
        parser.setFeature(feature_external_ges, True)
        print(request.data)
        payload = request.data.decode()
        print(payload)
        if "!ENTITY" in payload:
            return("Hackers Gonna Hack")
        # fitur encode
        if "UTF-7" in payload or "utf-7" in payload:
            payload = request.data.decode("utf-7")
        elif "UTF-8" in payload or "utf-8" in payload:
            payload = request.data.decode("utf-8")   
        else:
            return('''Masih support utf-7 dan utf-8 :(. Contoh request body:
            <?xml version="1.0" encoding="UTF-8"?>
            <data>
                <username>Tove</username>
            </data>''')
        doc = parseString(payload, parser=parser)
        username = ""
        for event, node in doc:
            if event == pulldom.START_ELEMENT and node.tagName == 'username':
                doc.expandNode(node)
                username = node.toxml()
            
        return("Terimakasih " + str(username))
    except:
        return("error bang")

if __name__ == '__main__':
    app.run(debug=True,host='127.0.0.1', port=6969)