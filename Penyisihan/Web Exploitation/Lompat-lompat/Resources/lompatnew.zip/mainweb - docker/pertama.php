<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pertama</title>
    <style>
    .footer {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      background-color: blue;
      color: white;
      text-align: center;
     }
    </style>
</head>
<body>
    <p>Webinar 1 : basic html</p>
    <img style="height:600;width:auto" src="https://lkpkaryaprima.id/wp-content/uploads/2021/08/HTML.png"/>
    <footer class="footer">Sepertinya /etc/rahasia/password menarik</footer>
</body>
</html>