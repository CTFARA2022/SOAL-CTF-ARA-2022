<html>
<p>Berikut Info tentang webinar :</p>
<?php
  $daftar = array("pertama.php", "kedua.php", "ketiga.php", "/etc/rahasia/password");
  $file = $_GET['file'];
  if (in_array($file, $daftar)){
   include($file);
  }
  else{
   echo("<p>Terlarang</p>");
  }
?>
</html>