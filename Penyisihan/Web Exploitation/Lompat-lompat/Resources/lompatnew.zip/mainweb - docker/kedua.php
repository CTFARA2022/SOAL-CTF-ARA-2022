<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kedua</title>
    <style>
    .footer {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      background-color: blue;
      color: white;
      text-align: center;
     }
    </style>
</head>
<body>
    <p>Webinar 2 : basic css</p>
    <img src="https://www.oxfordwebstudio.com/user/pages/06.da-li-znate/sta-je-css/sta-je-css.png">
    <footer class="footer">Sepertinya /etc/rahasia/password menarik</footer>
</body>
</html>