<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Page</title>
</head>
<body>
    Select your webinar :
    <form action="webinar.php" method="get">
        <input type="radio" id="pertama" name="file" value="pertama.php">
        <label for="pertama">First</label><br>
        <input type="radio" id="kedua" name="file" value="kedua.php">
        <label for="kedua">Second</label><br>
        <input type="radio" id="ketiga" name="file" value="ketiga.php">
        <label for="ketiga">Third</label>
        <br>
        <button type="submit">go</button>
    </form>
</body>
</html>