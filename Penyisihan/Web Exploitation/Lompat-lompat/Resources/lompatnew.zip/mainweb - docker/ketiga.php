<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ketiga</title>
    <style>
    .footer {
     position: fixed;
     left: 0;
     bottom: 0;
     width: 100%;
     background-color: yellow;
     color: black;
     text-align: center;
    }
   </style>
</head>
<body>
    <p>Webinar 3 : basic js</p>
    <img src="https://gmedia.net.id/upload/foto_artikel/20200828JYGqCbDK9l.jpg" style="height:600px;width:auto">
    <footer class="footer">Sepertinya /etc/rahasia/password menarik</footer>
</body>
</html>